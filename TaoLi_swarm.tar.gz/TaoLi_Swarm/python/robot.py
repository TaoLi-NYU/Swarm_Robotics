import numpy as np
import pybullet as p


class Robot():
    """ 
    The class is the interface to a single robot
    """

    def __init__(self, init_pos, robot_id, robot_state, dt):
        self.id = robot_id
        self.state = robot_state
        self.dt = dt
        self.pybullet_id = p.loadSDF("../models/robot.sdf")[0]
        self.joint_ids = list(range(p.getNumJoints(self.pybullet_id)))
        self.initial_position = init_pos
        self.reset()

        # No friction between bbody and surface.
        p.changeDynamics(self.pybullet_id, -1, lateralFriction=5., rollingFriction=0.)

        # Friction between joint links and surface.
        for i in range(p.getNumJoints(self.pybullet_id)):
            p.changeDynamics(self.pybullet_id, i, lateralFriction=5., rollingFriction=0.)

        self.messages_received = []
        self.messages_to_send = []
        self.neighbors = []

    def reset(self):
        """
        Moves the robot back to its initial position 
        """
        p.resetBasePositionAndOrientation(self.pybullet_id, self.initial_position, (0., 0., 0., 1.))

    def set_wheel_velocity(self, vel):
        """ 
        Sets the wheel velocity,expects an array containing two numbers (left and right wheel vel) 
        """
        assert len(vel) == 2, "Expect velocity to be array of size two"
        p.setJointMotorControlArray(self.pybullet_id, self.joint_ids, p.VELOCITY_CONTROL,
                                    targetVelocities=vel)

    def get_pos_and_orientation(self):
        """
        Returns the position and orientation (as Yaw angle) of the robot.
        """
        pos, rot = p.getBasePositionAndOrientation(self.pybullet_id)
        euler = p.getEulerFromQuaternion(rot)
        return np.array(pos), euler[2]

    def get_messages(self):
        """
        returns a list of received messages, each element of the list is a tuple (a,b)
        where a= id of the sending robot and b= message (can be any object, list, etc chosen by user)
        Note that the message will only be received if the robot is a neighbor (i.e. is close enough)
        """
        return self.messages_received

    def send_message(self, robot_id, message):
        """
        sends a message to robot with id number robot_id, the message can be any object, list, etc
        """
        self.messages_to_send.append([robot_id, message])

    def get_neighbors(self):
        """
        returns a list of neighbors (i.e. robots within 2m distance) to which messages can be sent
        """
        return self.neighbors

    def robot_velocity(self, dx, dy, rot, bnd=4, up_bnd=10):
        """
        compute the velocity of the robot
        dx,dy denote the position changes in x and y axis respectively
        """
        # compute velocity change for the wheels
        vel_norm = np.linalg.norm([dx, dy])  # norm of desired velocity
        if vel_norm < 0.1:
            vel_norm = bnd
        if vel_norm > 10:
            vel_norm = up_bnd
        des_theta = np.arctan2(dy / vel_norm, dx / vel_norm)
        right_wheel = np.sin(des_theta - rot) * vel_norm + np.cos(des_theta - rot) * vel_norm
        left_wheel = -np.sin(des_theta - rot) * vel_norm + np.cos(des_theta - rot) * vel_norm
        self.set_wheel_velocity([left_wheel, right_wheel])

    def neigh_state(self):
        """
        Check whether neighbors are in the same states
        """
        messages = self.get_messages()
        for m in messages:
            if self.state > m[1][1]:
                return False  # one of neighbors lag behind
        return True

    def linear_weight_fromation(self, ref, delta=2):
        """
        Linear formation control with edge tension
        input: ref: reference states; delta: communication distance
        """
        neig = self.get_neighbors()
        messages = self.get_messages()
        pos, rot = self.get_pos_and_orientation()
        # send messages to neighbots
        for n in neig:
            self.send_message(n, [pos, self.state])

        pos_self = np.array([pos[0], pos[1]])
        temp = np.zeros(2)
        # pos_neig and ref_ neig keep records of neighbors positions and reference states
        # to determine whether formation is achieved
        pos_neig = pos_self
        ref_neig = ref[self.id, :]
        if messages:
            for m in messages:
                j = m[0]
                pos_3d = m[1][0]
                # pos_j is the neighbor's position
                pos_j = np.array([pos_3d[0], pos_3d[1]])
                # add the new position to the record
                pos_neig = np.vstack((pos_neig, pos_j))
                ref_neig = np.vstack((ref_neig, ref[j, :]))
                # compute the control contributed by each neighbor
                d = ref[self.id, :] - ref[j, :]
                l = pos_self - pos_j
                d_norm = np.linalg.norm(d)
                dl_norm = np.linalg.norm(d - l)
                numerator = 2 * (delta - d_norm) - dl_norm
                denominator = (delta - d_norm - dl_norm)
                # if denominator > 1e-3:
                denominator_2 = denominator * denominator
                # summation of all neighbors'
                temp += (-numerator / denominator_2) * (l - d)
            # compare robots' positions with reference states
            translation = pos_neig - ref_neig
            ex = translation[:, 0].max() - translation[:, 0].min()
            ey = translation[:, 1].max() - translation[:, 1].min()
            e = max(ex, ey)
            return temp, rot, e
        else:  # if there is no messages, set velocity zero
            return np.zeros(2), rot, 1

    def linear_formation_move(self, ref, des, tol=0.2, tol_1=0.2, k=2):
        """Move the formationusing linear control law
        input: ref: reference states for formation; des: desired position;
                tol: error tolerance for preserving the formation
                tol_1: error tolerance for location
                k: factor for adjusting moving speed
        """
        # achieve the formation
        velocity, rot, e = self.linear_weight_fromation(ref)
        print([0, self.id, e])
        # if the formation is completed
        if e < tol:
            pos, _ = self.get_pos_and_orientation()
            pos_self = np.array([pos[0], pos[1]])
            # measure the distance between current position and the desired one
            e_norm = np.linalg.norm(des[self.id, :] - pos_self, 2, axis=0)
            e_1 = e_norm.max()
            print([1, self.id, e_1])
            # if the distance is below the tolerance then move to next control state
            if e_1 < tol_1:
                self.state += 1
            # otherwise move towards the desired position
            grad = k * (des[self.id, :] - pos_self)
            self.robot_velocity(grad[0], grad[1], rot)
        else:
            self.robot_velocity(velocity[0], velocity[1], rot)

    def potential_field_gradient(self, leaders, alpha_ind, safe_dist):
        """
        Compute the gradient of sum of potential fields
        input: leaders: the positions of leaders
                alpha_ind: speed factor for each individual
                safe_dist: safety distance for robots
        """
        neig = self.get_neighbors()
        messages = self.get_messages()
        pos, rot = self.get_pos_and_orientation()
        for n in neig:
            self.send_message(n, [pos, self.state])

        pos_self = np.array([pos[0], pos[1]])
        # length: the number of leaders (in our case, only one leader is needed)
        length = len(leaders)
        alpha_leader = np.zeros(length)
        dist_leader = np.zeros(length)
        pos_leader = np.zeros((length, 2))
        # for each leader, record the desired distance and position
        for i in range(length):
            alpha_leader[i] = leaders[i][0]
            dist_leader[i] = leaders[i][1]
            pos_leader[i, :] = leaders[i][2]
        # individual
        grad_ind = np.zeros(2)
        # for each neighbor, compute the gradient
        for m in messages:
            pos3d = m[1][0]
            pos_j = np.array([pos3d[0], pos3d[1]])
            diff = pos_self - pos_j
            d_norm = np.linalg.norm(diff)
            grad_ind += (d_norm - safe_dist) / np.power(d_norm, 3) * diff
        # for each leader, compute the gradient
        grad_leaders = np.zeros(2)
        for i in range(length):
            diff_leader = pos_self - pos_leader[i, :]
            d_norm = np.linalg.norm(diff_leader)
            grad_leaders += alpha_leader[i] * (d_norm - dist_leader[i]) / np.power(d_norm, 3) * diff_leader
        grad = -alpha_ind * grad_ind - grad_leaders
        velocity = grad * self.dt
        e = np.linalg.norm(velocity, 1)
        return velocity, rot, e

    def compute_controller(self, state):
        """ 
        During different control stages(indicated by the input argument state), different controls will be applied
        State 0: linear formation control for square formation
                self.linear_weight_formation
        State 1: linear formation control for changing the formation and move it to the front
                self.linear_formation_move
        State 2: linear formation control for preserving the formation and move it through the door
                self.linear_formation_move
        State 3 and 4: linear formation control for changing the formation to a square one
                     and make it enclose the purple ball when being outside
        State 5: Potential field for make robots cage the ball with a circle formation
                self.potential_field_gradient
        State 6: Linear control for caging and moving the object to the purple square
                self.linear formation_move
        State 7: Linear control for changing the formation for uncaging the ball and leave for the red ball
                self.linear_formation_move
        State 8: Linear formation control for changing the formation for approaching the red ball
                self.linear_formation_move
        State 9: Linear formation control for caging the red ball and moving it to the red square
                self.linear_formation_move
        State 10: Linear formation control for changing the formation in order to leave the red square and move to location 3
                self.linear_formation_move
        State 11: Linear formation control for changing the formation and moving through the door
                self.linear_formation_move
        State 12: Linear formation control for moving the robots to the center of the room
                self.linear_formation_move
        State 13: Linear foramtion control for making a diamond formation
                self.linear_weight_foramtion
        """

        if state == 0:
            tol = 0.15  # error tolerance
            # square formation reference
            ref = np.array([[1, -0.5], [1, 0.5], [1.5, -0.5], [1.5, 0.5], [2, -0.5], [2, 0.5]])
            # linear formation control
            velocity, rot, e = self.linear_weight_fromation(ref)
            # if the formation is achieved,
            if e < tol:
                self.state += 1
            else:
                self.robot_velocity(velocity[0], velocity[1], rot)

        elif state == 1:
            # if all neighbors are ready then implement the new control
            if self.neigh_state():
                # formation specification
                ref = np.array([[1.3, -0.8], [1.3, 0.8], [1.5, -0.2], [1.5, 0.2], [1.7, -0.8], [1.7, 0.8]])
                # destination
                des_1 = np.array([[2.4, -0.8], [2.4, 0.8], [2.6, -0.2], [2.6, 0.2], [2.8, -0.8], [2.8, 0.8]])
                self.linear_formation_move(ref, des_1, tol=0.205, tol_1=0.26, k=5)
            else:
                # the robot has to stay where it is waiting
                self.set_wheel_velocity([0, 0])

        elif state == 2:
            # send messages to all neighbors
            neig = self.get_neighbors()
            pos, rot = self.get_pos_and_orientation()
            for n in neig:
                self.send_message(n, [pos, self.state])

            if self.neigh_state():
                # change formation
                ref = np.array([[2.4, -0.8], [2.4, 0.8], [2.6, -0.2], [2.6, 0.2], [2.8, -0.8], [2.8, 0.8]])
                # the destination outside the room
                des_2 = np.array([[2.3, 2.4], [2.3, 4], [2.5, 3], [2.5, 3.4], [2.7, 2.4], [2.7, 4]])
                self.linear_formation_move(ref, des_2, tol=0.205, tol_1=0.26, k=5)
            else:
                self.set_wheel_velocity([0, 0])

        elif state == 3:
            neig = self.get_neighbors()
            pos, rot = self.get_pos_and_orientation()
            for n in neig:
                self.send_message(n, [pos, self.state])
            if self.neigh_state():
                # reference sprecification
                ref = np.array([[3, 2.8], [3, 3.8], [3.5, 2.8], [3.5, 3.8], [4, 2.8], [4, 3.8]])
                # move the robots to location 3
                des = np.array([[3, 3.5], [3, 4.5], [3.5, 3.5], [3.5, 4.5], [4, 3.5], [4, 4.5]])
                self.linear_formation_move(ref, des, tol=0.205, tol_1=0.26, k=10)
            else:
                self.set_wheel_velocity([0, 0])

        elif state == 4:
            neig = self.get_neighbors()
            pos, rot = self.get_pos_and_orientation()
            for n in neig:
                self.send_message(n, [pos, self.state])
            if self.neigh_state():
                # from location 3 to location 4
                ref = np.array([[3, 3.5], [3, 4.5], [3.4, 3.5], [3.4, 4.5], [3.8, 3.5], [3.8, 4.5]])
                des = np.array([[1.5, 3.5], [1.5, 4.5], [1.9, 3.5], [1.9, 4.5], [2.3, 3.5], [2.3, 4.5]])
                self.linear_formation_move(ref, des, tol=0.205, tol_1=0.26, k=5)
            else:
                self.set_wheel_velocity([0, 0])

        elif state == 5:
            neig = self.get_neighbors()
            pos, rot = self.get_pos_and_orientation()
            for n in neig:
                self.send_message(n, [pos, self.state])
            if self.neigh_state():
                tol = 1.382  # gradient error tolerance
                alpha = 500  # factor for the leader
                radius = 0.4  # desired distance for the leader
                scale = 0.5  # scale factor for adjusting the shape
                leader = [[alpha, radius, np.array([2, 4])]]  # leader's position
                des_dist = scale * radius * 10 * (4 * np.sqrt(3) - 3) / 13  # desired distance between robots
                velocity, rot, e = self.potential_field_gradient(leader, alpha_ind=500, safe_dist=des_dist)
                print([5, self.id, e])
                # if formation is achieved, get ready for next control law
                if e < tol:
                    self.state += 1
                self.robot_velocity(velocity[0], velocity[1], rot, bnd=5, up_bnd=10)
            else:
                self.set_wheel_velocity([0, 0])
        elif state == 6:
            neig = self.get_neighbors()
            pos, rot = self.get_pos_and_orientation()
            for n in neig:
                self.send_message(n, [pos, self.state])
            if self.neigh_state():
                # ref = np.array([[1.656, 3.784], [1.675, 4.192], [2, 3.714], [2, 4.310], [2.368, 3.805], [2.368, 4.215]])
                # des = np.array(
                #   [[2.156, 5.284], [2.175, 5.692], [2.5, 5.214], [2.5, 5.810], [2.868, 5.305], [2.868, 5.715]])
                # specify the formation and destination
                radius = 0.6
                dx = 0.5 * radius * np.sqrt(3)
                dy = 0.5 * radius
                ref = np.array(
                    [[2 - dx, 4 - dy], [2 - dx, 4 + dy], [2, 3.6], [2, 4.4], [2 + dx, 4 - dy], [2 + dx, 4 + dy]])
                des = np.zeros((6, 2))
                des[:, 0] = ref[:, 0] + 0.5 * np.ones(6)
                des[:, 1] = ref[:, 1] + 1.5 * np.ones(6)
                self.linear_formation_move(ref, des, tol=0.214, tol_1=0.2, k=6)
            else:
                self.set_wheel_velocity([0, 0])

        elif state == 7:
            neig = self.get_neighbors()
            pos, rot = self.get_pos_and_orientation()
            for n in neig:
                self.send_message(n, [pos, self.state])
            if self.neigh_state():
                #  make new formation and leave for the purple ball
                ref = np.array([[2.1, 5], [2.1, 6], [2.5, 5], [2.5, 6], [2.9, 5], [2.9, 6]])
                des = np.array([[3.6, 5], [3.6, 6], [4, 5], [4, 6], [4.4, 5], [4.4, 6]])
                self.linear_formation_move(ref, des, tol=0.21, tol_1=0.2, k=5)
            else:
                self.set_wheel_velocity([0, 0])
        elif state == 8:
            neig = self.get_neighbors()
            pos, rot = self.get_pos_and_orientation()
            for n in neig:
                self.send_message(n, [pos, self.state])
            if self.neigh_state():
                # again change the formation and approach the red ball
                ref = np.array([[3.6, 5], [3.6, 6], [3.6, 5.5], [4.4, 5.5], [4.4, 5], [4.4, 6]])
                des = np.array([[3.6, 1.5], [3.6, 2.5], [3.6, 2], [4.4, 2], [4.4, 1.5], [4.4, 2.5]])
                self.linear_formation_move(ref, des, tol=0.21, tol_1=0.26, k=5)
            else:
                self.set_wheel_velocity([0, 0])
        elif state == 9:
            neig = self.get_neighbors()
            pos, rot = self.get_pos_and_orientation()
            for n in neig:
                self.send_message(n, [pos, self.state])
            if self.neigh_state():
                # cage the red ball and move it to the red square
                radius = 0.4
                dy = 0.5 * radius * np.sqrt(3)
                dx = 0.5 * radius
                ref = np.array(
                    [[4 - dx, 2 - dy], [4 - dx, 2 + dy], [3.6, 2], [4.4, 2], [4 + dx, 2 - dy], [4 + dx, 2 + dy]])
                des = np.zeros((6, 2))
                des[:, 0] = ref[:, 0] - 3.5 * np.ones(6)
                des[:, 1] = ref[:, 1] + 3.5 * np.ones(6)
                self.linear_formation_move(ref, des, tol=0.26, tol_1=0.21, k=6)
            else:
                self.set_wheel_velocity([0, 0])
        elif state == 10:
            neig = self.get_neighbors()
            pos, rot = self.get_pos_and_orientation()
            for n in neig:
                self.send_message(n, [pos, self.state])
            if self.neigh_state():
                # change the formation and leave the rea square
                ref = np.array([[-0.1, 5.1], [-0.1, 5.9], [0.5, 5.1], [0.5, 5.9], [1.1, 5.1], [1.1, 5.9]])
                des = np.array([[1.9, 5.1], [1.9, 5.9], [2.5, 5.1], [2.5, 5.9], [3.1, 5.1], [3.1, 5.9]])
                self.linear_formation_move(ref, des, tol=0.206, tol_1=0.2, k=5)
            else:
                self.set_wheel_velocity([0, 0])
        elif state == 11:
            neig = self.get_neighbors()
            pos, rot = self.get_pos_and_orientation()
            for n in neig:
                self.send_message(n, [pos, self.state])
            if self.neigh_state():
                # change the formation and move towards the door
                ref = np.array([[2.3, 4.7], [2.3, 6.3], [2.5, 5.3], [2.5, 5.7], [2.7, 4.7], [2.7, 6.3]])
                des = np.array([[2.3, -0.8], [2.3, 0.8], [2.5, -0.2], [2.5, 0.2], [2.7, -0.8], [2.7, 0.8]])
                # des = np.array([[2.3, 2.4], [2.3, 4], [2.5, 3], [2.5, 3.4], [2.7, 2.4], [2.7, 4]])
                self.linear_formation_move(ref, des, tol=0.214, tol_1=0.2, k=4)
            else:
                self.set_wheel_velocity([0, 0])
        elif state == 12:
            neig = self.get_neighbors()
            pos, rot = self.get_pos_and_orientation()
            for n in neig:
                self.send_message(n, [pos, self.state])
            if self.neigh_state():
                # get indoor and move to the center of the room
                ref = np.array([[2.3, -0.8], [2.3, 0.8], [2.5, -0.2], [2.5, 0.2], [2.7, -0.8], [2.7, 0.8]])
                des = np.array([[1.3, -0.8], [1.3, 0.8], [1.5, -0.2], [1.5, 0.2], [1.7, -0.8], [1.7, 0.8]])
                self.linear_formation_move(ref, des, tol=0.214, tol_1=0.1, k=8)
            else:
                self.set_wheel_velocity([0, 0])

        elif state == 13:
            neig = self.get_neighbors()
            pos, rot = self.get_pos_and_orientation()
            for n in neig:
                self.send_message(n, [pos, self.state])
            if self.neigh_state():
                tol = 0.15
                # make a diamond formation
                ref = np.array([[1.5, -0.6], [0.9, 0], [1.5, -0.2], [1.5, 0.2], [2.1, 0], [1.5, 0.6]])
                velocity, rot, e = self.linear_weight_fromation(ref)
                # if the formation is achieved,
                if e < tol:
                    self.state += 1
                else:
                    self.robot_velocity(velocity[0], velocity[1], rot)

        else:
            neig = self.get_neighbors()
            pos, rot = self.get_pos_and_orientation()
            for n in neig:
                self.send_message(n, [pos, self.state])
            self.set_wheel_velocity([0, 0])
